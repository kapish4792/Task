$('.testimonial').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: false,
  autoplaySpeed: 2000,
  prevArrow:'<span class="prev-arrow"><i class="fas fa-chevron-left"></i></span>',
  nextArrow:'<span class="next-arrow"><i class="fas fa-chevron-right"></i></span>'
});

$('.clients').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 3000,
  prevArrow:'<span class="prev-arrow"><i class="fas fa-chevron-left"></i></span>',
  nextArrow:'<span class="next-arrow"><i class="fas fa-chevron-right"></i></span>',
  responsive: [
  {
      breakpoint: 1000,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 2,
        slidesToScroll:2
      }
    }

  ]
});
